// modules/stock.js — Lógica del módulo Stock.
// Se conecta al Apps Script (API_URL, definido en assets/config.js).

let stockData = [];
let pendingItem = null;   // { id, ubicacion, row }
let pendingAction = null; // 'Entrada' | 'Salida'

// Punto de entrada: app.js llama a esta función luego de inyectar modules/stock.html
window.initStockModule = function () {
  fetchStock();

  document.getElementById('btn-buscar-stock').addEventListener('click', renderFiltered);
  document.getElementById('stock-search-input').addEventListener('keyup', (e) => {
    if (e.key === 'Enter') renderFiltered();
  });
  document.getElementById('stock-filter-estado').addEventListener('change', renderFiltered);

  document.getElementById('stock-tbody').addEventListener('click', handleTableClick);
  document.getElementById('quick-panel-close').addEventListener('click', closeQuickPanel);
  document.getElementById('quick-panel-confirm').addEventListener('click', confirmMovimiento);
  document.getElementById('location-panel-close').addEventListener('click', closeLocationPanel);
  document.getElementById('location-panel-confirm').addEventListener('click', confirmLocation);
  document.getElementById('btn-escanear').addEventListener('click', openScanner);
  document.getElementById('scanner-panel-close').addEventListener('click', closeScanner);
  document.getElementById('stock-filter-almacen').addEventListener('change', renderFiltered);
  document.getElementById('loc-almacen').addEventListener('change', toggleCamposAlmacen);
    ['filter-cliente','filter-medida','filter-ubicacion','filter-color','filter-ancho','filter-largo','filter-espesor']
  .forEach((id) => document.getElementById(id).addEventListener('keyup', renderFiltered));

document.getElementById('btn-limpiar-filtros').addEventListener('click', () => {
  document.getElementById('stock-search-input').value = '';
  document.getElementById('stock-filter-estado').value = '';
  ['filter-cliente','filter-medida','filter-ubicacion','filter-color','filter-ancho','filter-largo','filter-espesor']
    .forEach((id) => document.getElementById(id).value = '');
  renderFiltered();
});
  
};

// ====== Traer datos desde el Apps Script ======
function fetchStock() {
  setStatus('Cargando stock…');
  const tbody = document.getElementById('stock-tbody');
  tbody.innerHTML = `<tr><td colspan="6">Cargando…</td></tr>`;

  fetch(`${API_URL}?action=stock&_=${Date.now()}`, { cache: 'no-store' })
    .then((r) => r.json())
    .then((data) => {
      if (data.error) throw new Error(data.error);
      stockData = data;
      renderFiltered();
      setStatus('Listo');
    })
    .catch((err) => {
      tbody.innerHTML = `<tr><td colspan="6">Error al cargar: ${err.message}. Revisa API_URL en assets/config.js.</td></tr>`;
      setStatus('Error al cargar stock');
    });
}

// ====== Filtrar y pintar la tabla ======
function renderFiltered() {
  const term = (document.getElementById('stock-search-input').value || '').toLowerCase();
  const estadoFiltro = document.getElementById('stock-filter-estado').value;
  const clienteFiltro = (document.getElementById('filter-cliente').value || '').toLowerCase();
  const medidaFiltro = (document.getElementById('filter-medida').value || '').toLowerCase();
  const ubicacionFiltro = (document.getElementById('filter-ubicacion').value || '').toLowerCase();
  const colorFiltro = (document.getElementById('filter-color').value || '').toLowerCase();
  const anchoFiltro = (document.getElementById('filter-ancho').value || '').toLowerCase();
  const largoFiltro = (document.getElementById('filter-largo').value || '').toLowerCase();
  const espesorFiltro = (document.getElementById('filter-espesor').value || '').toLowerCase();
  const almacenFiltro = document.getElementById('stock-filter-almacen').value;

  const filtrados = stockData.filter((item) => {
    const campos = [item.id, item.descripcion, item.empresa, item.cliente];
    const coincideTexto = !term || campos.some((c) => String(c || '').toLowerCase().includes(term));

    const coincide = (valor, filtro) => !filtro || String(valor || '').toLowerCase().includes(filtro);

    return coincideTexto
      && (!estadoFiltro || item.estado === estadoFiltro)
      && coincide(item.cliente, clienteFiltro)
      && coincide(item.litraje, medidaFiltro)
      && coincide(item.ubicacion, ubicacionFiltro)
      && coincide(item.color, colorFiltro)
      && coincide(item.ancho, anchoFiltro)
      && coincide(item.largo, largoFiltro)
      && coincide(item.espesor, espesorFiltro)
      && (!almacenFiltro || item.almacen === almacenFiltro);
  });

  const tbody = document.getElementById('stock-tbody');
  tbody.innerHTML = filtrados.length
    ? filtrados.map(rowHtml).join('')
    : `<tr><td colspan="13">No se encontraron artículos.</td></tr>`;

  updateMetrics();
}

function rowHtml(item) {
  const sinUbicar = item.ubicacion === 'Sin ubicar';
  const badgeClass = sinUbicar ? 'badge-neutral'
    : item.estado === 'Normal' ? 'badge-ok'
    : item.estado === 'Bajo mínimo' ? 'badge-warn'
    : 'badge-danger';

  const accionesHtml = sinUbicar
    ? `<button class="btn-classic btn-icon-sm" style="width:auto; padding:0 8px;" data-action="ubicar" title="Asignar ubicación">📍 Ubicar</button>`
    : `<div class="row-actions">
         <button class="btn-classic btn-icon-sm btn-ok" data-action="Entrada" title="Ingreso">↑</button>
         <button class="btn-classic btn-icon-sm btn-danger" data-action="Salida" title="Venta">↓</button>
       </div>`;

  return `
    <tr class="selectable" data-id="${item.id}" data-ubicacion="${item.ubicacion}">
      <td data-label="ID">${item.id}</td>
      <td data-label="Descripción">${item.descripcion}</td>
      <td data-label="Litraje">${item.litraje}</td>
      <td data-label="Color">${item.color}</td>
      <td data-label="C/F">${item.cf}</td>
      <td data-label="Ancho">${item.ancho}</td>
      <td data-label="Largo">${item.largo}</td>
      <td data-label="Espesor">${item.espesor}</td>
      <td data-label="Empresa">${item.empresa}</td>
      <td data-label="Cliente">${item.cliente}</td>
      <td data-label="Almacén">${item.almacen}</td>
      <td data-label="Ubicación">${item.ubicacion}</td>
      <td class="qty-cell" data-label="Disponible">${item.disponible}</td>
      <td data-label="Estado"><span class="badge ${badgeClass}">${item.estado}</span></td>
      <td data-label="Acciones">${accionesHtml}</td>
    </tr>`;
}

function updateMetrics() {
  document.getElementById('metric-disponible').textContent =
    stockData.reduce((sum, i) => sum + i.disponible, 0);
  document.getElementById('metric-bajo-minimo').textContent =
    stockData.filter((i) => i.estado === 'Bajo mínimo').length;
  document.getElementById('metric-sin-stock').textContent =
    stockData.filter((i) => i.estado === 'Sin stock').length;
  document.getElementById('metric-sin-ubicar').textContent =
    stockData.filter((i) => i.estado === 'Sin ubicar').length;
}

// ====== Selección de fila y acciones rápidas ======
function handleTableClick(e) {
  const row = e.target.closest('tr');
  if (!row || !row.dataset.id) return;

  document.querySelectorAll('#stock-tbody tr').forEach((r) => r.classList.remove('row-selected'));
  row.classList.add('row-selected');

  const actionBtn = e.target.closest('[data-action]');
  if (!actionBtn) return;

  if (actionBtn.dataset.action === 'ubicar') {
    pendingItem = { id: row.dataset.id, ubicacion: row.dataset.ubicacion, row };
    openLocationPanel();
  } else {
    pendingItem = { id: row.dataset.id, ubicacion: row.dataset.ubicacion, row };
    pendingAction = actionBtn.dataset.action;
    openQuickPanel();
  }
}

function openQuickPanel() {
  const panel = document.getElementById('quick-panel');
  const motivoSelect = document.getElementById('quick-panel-motivo');

  document.getElementById('quick-panel-item').textContent =
    `${pendingItem.id} (${pendingAction === 'Entrada' ? 'Ingreso' : 'Venta'})`;

  motivoSelect.innerHTML = pendingAction === 'Entrada'
    ? '<option>Compra / Reposición</option><option>Devolución</option><option>Ajuste de inventario</option>'
    : '<option>Venta</option><option>Ajuste de inventario</option>';

  panel.classList.add('show');
  document.getElementById('quick-panel-qty').focus();
}

function closeQuickPanel() {
  document.getElementById('quick-panel').classList.remove('show');
  pendingItem = null;
  pendingAction = null;
}

// ====== Confirmar movimiento: POST al Apps Script ======
function confirmMovimiento() {
  if (!pendingItem) return;

  const cantidad = parseInt(document.getElementById('quick-panel-qty').value, 10) || 0;
  const motivo = document.getElementById('quick-panel-motivo').value;
  const confirmBtn = document.getElementById('quick-panel-confirm');

  confirmBtn.textContent = 'Guardando…';
  confirmBtn.disabled = true;
  setStatus('Guardando movimiento…');

  // Nota: se envía el body como string (sin header Content-Type manual) para
  // que sea una "solicitud simple" y Apps Script la reciba sin problemas de CORS.
  fetch(API_URL, {
    method: 'POST',
    body: JSON.stringify({
      action: 'movimiento',
      id_articulo: pendingItem.id,
      id_ubicacion: pendingItem.ubicacion,
      tipo: pendingAction,
      cantidad: cantidad,
      motivo: motivo,
      usuario: 'admin' // por ahora fijo; más adelante se conecta a un login real
    })
  })
    .then((r) => r.json())
    .then((resultado) => {
      if (resultado.ok) {
        pendingItem.row.querySelector('.qty-cell').textContent = resultado.nuevoStock;
        const item = stockData.find((i) => i.id === pendingItem.id && i.ubicacion === pendingItem.ubicacion);
        if (item) item.disponible = resultado.nuevoStock;
        setStatus('Movimiento guardado');
      } else {
        setStatus('Error: ' + (resultado.error || 'no se pudo guardar'));
      }
      closeQuickPanel();
    })
    .catch((err) => {
      setStatus('Error de conexión: ' + err.message);
    })
    .finally(() => {
      confirmBtn.textContent = '✔ Confirmar';
      confirmBtn.disabled = false;
    });
}
function openLocationPanel() {
  document.getElementById('location-panel-item').textContent = `${pendingItem.id}`;

  const ultima = JSON.parse(localStorage.getItem('ultimaUbicacion') || 'null');
  if (ultima) {
    document.getElementById('loc-almacen').value = ultima.almacen || 'Almacén 2';
    if (ultima.almacen === 'Almacén 1') {
      document.getElementById('loc-mueble').value = ultima.mueble;
      document.getElementById('loc-nivel-a1').value = ultima.nivel;
    } else {
      document.getElementById('loc-fila').value = ultima.fila;
      document.getElementById('loc-modulo').value = ultima.modulo;
      document.getElementById('loc-lado').value = ultima.lado;
      document.getElementById('loc-nivel').value = ultima.nivel;
    }
  }
  toggleCamposAlmacen();

  document.getElementById('location-panel').classList.add('show');
}

function toggleCamposAlmacen() {
  const almacen = document.getElementById('loc-almacen').value;
  document.getElementById('loc-fields-almacen1').style.display = almacen === 'Almacén 1' ? 'flex' : 'none';
  document.getElementById('loc-fields-almacen2').style.display = almacen === 'Almacén 2' ? 'flex' : 'none';
}

function closeLocationPanel() {
  document.getElementById('location-panel').classList.remove('show');
  pendingItem = null;
}

function confirmLocation() {
  if (!pendingItem) return;

  const almacen = document.getElementById('loc-almacen').value;
  let fila = '', modulo = '', lado = '', mueble = '', nivel = '';

  if (almacen === 'Almacén 1') {
    mueble = document.getElementById('loc-mueble').value;
    nivel = document.getElementById('loc-nivel-a1').value;
  } else {
    fila = document.getElementById('loc-fila').value;
    modulo = document.getElementById('loc-modulo').value;
    lado = document.getElementById('loc-lado').value;
    nivel = document.getElementById('loc-nivel').value;
  }

  const stockInicial = parseInt(document.getElementById('loc-stock-inicial').value, 10) || 0;
  const confirmBtn = document.getElementById('location-panel-confirm');

  localStorage.setItem('ultimaUbicacion', JSON.stringify({ almacen, fila, modulo, lado, mueble, nivel }));

  confirmBtn.textContent = 'Guardando…';
  confirmBtn.disabled = true;
  setStatus('Guardando ubicación…');

  fetch(API_URL, {
    method: 'POST',
    body: JSON.stringify({
      action: 'asignar_ubicacion',
      id_articulo: pendingItem.id,
      almacen, fila, modulo, lado, mueble, nivel,
      stock_inicial: stockInicial
    })
  })
    .then((r) => r.json())
    .then((resultado) => {
      if (resultado.ok) {
        setStatus('Ubicación asignada: ' + resultado.id_ubicacion);
        fetchStock();
      } else {
        setStatus('Error: ' + (resultado.error || 'no se pudo asignar'));
      }
      closeLocationPanel();
    })
    .catch((err) => setStatus('Error de conexión: ' + err.message))
    .finally(() => {
      confirmBtn.textContent = '✔ Confirmar';
      confirmBtn.disabled = false;
    });
}
function setStatus(msg) {
  const el = document.getElementById('status-message');
  if (el) el.textContent = msg;
}
let html5QrCode = null;
let scannerRunning = false;

function openScanner() {
  document.getElementById('scanner-panel').classList.add('show');
  document.getElementById('scanner-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });

  if (!html5QrCode) {
    html5QrCode = new Html5Qrcode('scanner-reader', {
      // Limita los formatos a los típicos de códigos de barras de productos
      // (menos formatos a probar = detección más rápida)
      formatsToSupport: [
        Html5QrcodeSupportedFormats.EAN_13,
        Html5QrcodeSupportedFormats.EAN_8,
        Html5QrcodeSupportedFormats.UPC_A,
        Html5QrcodeSupportedFormats.UPC_E,
        Html5QrcodeSupportedFormats.CODE_128,
        Html5QrcodeSupportedFormats.CODE_39,
        Html5QrcodeSupportedFormats.ITF
      ],
      // Usa el lector nativo del navegador cuando esté disponible (mucho más
      // rápido y preciso que el decodificador JS genérico)
      useBarCodeDetectorIfSupported: true
    });
  }

  const config = {
    fps: 20,
    // Rectángulo ancho y bajo, como la forma real de un código de barras
    // (en vez de un cuadrado, que es mejor para QR)
    qrbox: { width: 280, height: 110 },
    aspectRatio: 1.777,
    videoConstraints: {
      facingMode: 'environment',
      width: { ideal: 1920 },
      height: { ideal: 1080 },
      // Pide enfoque continuo si el celular lo soporta (más nitidez en movimiento)
      advanced: [{ focusMode: 'continuous' }]
    }
  };

  html5QrCode.start(
    { facingMode: 'environment' },
    config,
    (decodedText) => {
        reproducirBeep();
      document.getElementById('stock-search-input').value = decodedText;
      renderFiltered();
      closeScanner();
      setStatus('Código escaneado: ' + decodedText);
    },
    () => { /* ignoramos los frames donde no detecta nada, es normal */ }
  ).then(() => {
    scannerRunning = true;
  }).catch((err) => {
    setStatus('No se pudo abrir la cámara: ' + err);
    document.getElementById('scanner-panel').classList.remove('show');
  });
}
function reproducirBeep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const oscilador = ctx.createOscillator();
    const volumen = ctx.createGain();

    oscilador.connect(volumen);
    volumen.connect(ctx.destination);

    oscilador.type = 'sine';
    oscilador.frequency.value = 1000; // tono agudo, tipo beep de scanner
    volumen.gain.setValueAtTime(0.3, ctx.currentTime);
    volumen.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);

    oscilador.start();
    oscilador.stop(ctx.currentTime + 0.15); // dura 150ms, cortito
  } catch (err) {
    // Si el navegador bloquea el audio (por no haber interacción previa), no rompe nada
    console.warn('No se pudo reproducir el beep:', err);
  }
}

function closeScanner() {
  if (html5QrCode && scannerRunning) {
    html5QrCode.stop().then(() => { scannerRunning = false; }).catch(() => {});
  }
  document.getElementById('scanner-panel').classList.remove('show');
}

